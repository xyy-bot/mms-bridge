# VLM_for_tactile_sensing > 2025-02-05 1:10pm
https://universe.roboflow.com/vlam/vlm_for_tactile_sensing

Provided by a Roboflow user
License: CC BY 4.0

